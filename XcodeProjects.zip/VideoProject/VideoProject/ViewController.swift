//
//  ViewController.swift
//  VideoProject
//
//  Created by student on 4/16/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit
import AVKit


class ViewController: UIViewController {
    
    
    @IBAction func playButton(_ sender: UIButton) {
        // player
        let player = AVPlayer(url:videoURL)
        // player controller
        let playerController = AVPlayerViewController()
        playerController.player = player
        
        present(playerController, animated: true){
            player.play()
            
            
        }
    }
    let videoURL = URL(string: "http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8")!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

