//
//  ViewController.swift
//  TemperatureChanger
//
//  Created by student on 3/19/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var TextField: UITextField!
    
    @IBOutlet weak var celciusTemp: UILabel!
    
    
    var fahenheitValue: Measurement<UnitTemperature>?{
        didSet{
            updateCelsius()
        }
    }
    
    var celciusValue: Measurement<UnitTemperature>?{
        if let fahenheitValue = fahenheitValue{
            return fahenheitValue.converted(to: .celsius)
            
        }else{
            return nil
        }
    }
        @IBAction func fahenheitValue(_ sender: UITextField) {
    
        if let text = sender.text, let value = Double(text){
            fahenheitValue = Measurement(value:value, unit:.fahrenheit)}
        else{
            fahenheitValue = nil
            }
            
        }
    
    func updateCelsius(){
        if let celciusValue = celciusValue{
            celciusTemp.text = "\(celciusValue.value)"
        }
        else {
            celciusTemp.text = "???"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateCelsius()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

