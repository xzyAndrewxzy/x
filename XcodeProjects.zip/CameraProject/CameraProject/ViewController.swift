//
//  ViewController.swift
//  CameraProject
//
//  Created by student on 4/16/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit
import WebKit
class ViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate, WKUIDelegate {

    
    @IBAction func takePic(_ sender: UIBarButtonItem) {
        let imagePicker = UIImagePickerController()
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            imagePicker.sourceType = .camera
        }else{
            imagePicker.sourceType = .photoLibrary
        }
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
        
}
    
    
    var webView : WKWebView!
    @IBOutlet weak var webViewOutlet: WKWebView!
    
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView( frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
        
        
    }


    override func viewDidLoad() {
        //super.viewDidLoad()
       
       /* let myURL = URL(string: "https://www.apple.com")
        
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)*/
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
    
}


