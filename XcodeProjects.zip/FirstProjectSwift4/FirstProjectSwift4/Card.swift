//
//  Card.swift
//  FirstProjectSwift4
//
//  Created by drew salaz on 3/5/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import Foundation

struct Card {
    
    var isFaceUp = false
    var isMatched = false
    
    var identifier : Int! 
    
    
    
}
