//
//  ViewController.swift
//  FirstProjectSwift4
//
//  Created by drew salaz on 3/4/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var game : Concentration = Concentration()
    
    var flipcounter : Int = 0 {
        didSet { flipLabel.text = "Flips \(flipcounter)"
            
        }
    }
    
    @IBOutlet var emojiArrayButton: [UIButton]!
    
    @IBOutlet weak var flipLabel: UILabel!
    
    @IBAction func cardButton(_ sender: UIButton) {
        flipcounter += 1
      flipCard(withEmoji: "👻", on: sender)
        if let numberOfcardarr = emojiArrayButton.index(of: sender) {
        print( "card number is \(numberOfcardarr)")
       } else {
            print("not selected")
        }
        
        // just did the not selected all you have to do is reselecet button and contine to next vid
        
    }
    
   
  

    
    
    
    
    func flipCard( withEmoji emoji : String, on button : UIButton){
        if button.currentTitle == emoji {
            button.setTitle(" ", for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 0.2775733471, green: 0.4111432433, blue: 0.9077646136, alpha: 1)
            
        } else {
            button.setTitle(emoji, for: UIControlState.normal)
            button.backgroundColor = #colorLiteral(red: 0.4473794699, green: 0.2673788965, blue: 0.9100534916, alpha: 1)
            
        }
        
        
    }
    
    
    
    
    
}
