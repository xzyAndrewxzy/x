//
//  Concentration.swift
//  FirstProjectSwift4
//
//  Created by drew salaz on 3/5/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import Foundation

class Concentration {
    var cards = [Card]()
    
    func chooseCard(at index : Int) {
        
        
        
    }
    
    
}
