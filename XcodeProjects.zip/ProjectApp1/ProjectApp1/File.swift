//
//  File.swift
//  ProjectApp1
//
//  Created by drew salaz on 5/11/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import MapKit

class PinLocation: NSObject, MKAnnotation{
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var subtitle: String?
    
    // fucntion
    init(title: String, coordinate: CLLocationCoordinate2D, subtitle: String) {
        
        // self is confirms values
        self.title = title
        self.coordinate = coordinate
        self.subtitle = subtitle
        
    }
    
    
    
    
    
    
}
