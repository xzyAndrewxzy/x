//
//  ContentOfList.swift
//  ProjectApp1
//
//  Created by drew salaz on 5/10/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import UIKit

class ContentOfList: NSObject {
    
    static var listContent = [String]()
    
    class func addToList ( newContent: String){
        
        ContentOfList.listContent.append(newContent)
        
    }
    
    

}
