//
//  UserProfileViewController.swift
//  ProjectApp1
//
//  Created by drew salaz on 5/10/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import UIKit

class UserProfileViewController: UIViewController {

   
    @IBOutlet weak var UserLabel: UILabel!
    
    @IBOutlet weak var PassLabel: UILabel!
    
    var userString = String()
    
    var passString = String()
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UserLabel.text = userString
        PassLabel.text = passString
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
