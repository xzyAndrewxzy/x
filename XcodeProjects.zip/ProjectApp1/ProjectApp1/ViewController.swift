//
//  ViewController.swift
//  ProjectApp1
//
//  Created by drew salaz on 5/10/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UserTextField: UITextField!
    
    @IBOutlet weak var PassTextField: UITextField!
    
    
    @IBAction func LoginButton(_ sender: UIButton) {
        if UserTextField.text != " " && PassTextField.text != " " {
           performSegue(withIdentifier: "LoginSegue", sender: self)
            
        }
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let UserProfileVC = segue.destination as! UserProfileViewController
        UserProfileVC.userString = UserTextField.text!
        UserProfileVC.passString = PassTextField.text!
    
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

