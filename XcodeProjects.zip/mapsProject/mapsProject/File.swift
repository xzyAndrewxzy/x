//
//  File.swift
//  mapsProject
//
//  Created by student on 4/23/18.
//  Copyright © 2018 student. All rights reserved.
//

import MapKit

class PinLocation: NSObject, MKAnnotation{
    var title: String?
    var coordinate: CLLocationCoordinate2D
    var subtitle: String?
    
   // fucntion
    init(title: String, coordinate: CLLocationCoordinate2D, subtitle: String) {
  
  // self is confirms values
    self.title = title
    self.coordinate = coordinate
    self.subtitle = subtitle
        
}
    
   
    
    
    
    
}
