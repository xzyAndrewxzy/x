//
//  ViewController.swift
//  mapsProject
//
//  Created by student on 4/23/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation // another form of finding location
class ViewController: UIViewController , MKMapViewDelegate {

    
    @IBOutlet weak var mapViewController: MKMapView!
    
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //
        
        // oatoh
        
        mapViewController.delegate = self
        
        // location
        
        // let latiude = 26.37
        let x : CLLocationDegrees = 26.379017
        // let Longitude = - 80.10
        let y : CLLocationDegrees = -80.101057
        
        
        // controlling the zoom
        
        // let latiudeDelta = 0.6
        let xDelta : CLLocationDegrees = 0.6
        
        // let Longitudedelta = 0.6
        let yDelta : CLLocationDegrees = 0.6
        
       // let tupleXY = (xDelta, yDelta )
        
       //delta
        let mapspan : MKCoordinateSpan = MKCoordinateSpanMake(xDelta, yDelta)
        // location
        let location : CLLocationCoordinate2D = CLLocationCoordinate2DMake(x, y)
        // location + delta
        let region : MKCoordinateRegion = MKCoordinateRegionMake( location, mapspan)
        
        //boolean code
        mapViewController.showsTraffic = true
        mapViewController.showsBuildings = true
        
        
        
        // code to run 
        mapViewController.setRegion(region, animated: true)
       // used latiude and longitdue insted of x and y
        let newPin = PinLocation(title: "palm beach state", coordinate: CLLocationCoordinate2D(latitude : 26.379017, longitude : -80.101057), subtitle: "plam beach state boca campus")
        
        // addAnnotation adds pin
        mapViewController.addAnnotation(newPin)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "PinLocation")
        
        annotationView.animatesDrop = true
        annotationView.canShowCallout = true
        return annotationView
        
    }

    
    
    func locationManager( _ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus){
        if ( status == .authorizedWhenInUse){
            mapViewController.showsUserLocation = true
locationManager.startUpdatingLocation()
        }
    }
    
}

