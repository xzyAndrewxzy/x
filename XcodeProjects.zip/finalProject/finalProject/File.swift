//
//  File.swift
//  finalProject
//
//  Created by student on 4/30/18.
//  Copyright © 2018 student. All rights reserved.
//

import Foundation
class file : NSObject{
    
    static var companiesArray = [String]()
    
    class func defaultCompany( newCompany:String){
        
        file.companiesArray.append(newCompany)
        
        
        
        
    }
    
    
    
    
}
