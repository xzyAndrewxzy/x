//
//  DetailViewController.swift
//  Homepwner
//
//  Created by student on 4/9/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController{
    @IBOutlet weak var label: UILabel!
    var labelVariable: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        label.text = labelVariable
    }
}
