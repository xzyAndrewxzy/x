//
//  itemStore.swift
//  Homepwner
//
//  Created by student on 4/2/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class ItemStore{
    var allItems = [Item]()

    @discardableResult func createItem() -> Item {
        let newItem = Item(random: true)
        allItems.append(newItem)
        
        return newItem
    }
    
    
    func removeItem (_ item: Item){
        if let index = allItems.index(of: item){
            allItems.remove(at: index)
        }
    }
    
    /*
    func moveItem (from fromIndex: Int, to toIndex: Int){
        if fromIndex == toIndex{
            return
        }
        // get reference to object being moved so you can reinsert it
        let moveItem = allItems[fromIndex]
        // remove item from array
        allItems.remove(at: fromIndex)
        // insert item in array at new location
        allItems.insert(moveItem, at:toIndex)
    }
    */
    init() {
        for _ in 0..<5{
            createItem()
        }
    }
    
}
