//
//  ViewController.swift
//  imageProject
//
//  Created by student on 4/23/18.
//  Copyright © 2018 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var viewCOntrollerImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        viewCOntrollerImage.image = UIImage(named : "8001625196_d7e1ccf0d0_o")
        
        //viewCOntrollerImage.image = UIImage(named: <#T##String#>)
        // could just drag into assets but if interaction is going to be done with picture its beter to code
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

