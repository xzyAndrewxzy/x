//
//  listContent.swift
//  FuckXcode
//
//  Created by drew salaz on 4/20/18.
//  Copyright © 2018 Drew. All rights reserved.
//

import UIKit

class listContent: NSObject {

    static var list = [String]()
    
    
    class func addToList ( newContent: String){
        
        listContent.list.append(newContent)
        
    }
    
    
}
